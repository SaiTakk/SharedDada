/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStackedWidget>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QStackedWidget *stackedWidget;
    QWidget *mainBodyPage;
    QLabel *background;
    QPushButton *btnSkull;
    QPushButton *btnSpine;
    QPushButton *btnRibs;
    QPushButton *btnChest;
    QPushButton *btnUExt;
    QPushButton *btnLExt;
    QPushButton *btnAbdomen;
    QLabel *bodyViewImage;
    QWidget *skullViewPage;
    QLabel *background_2;
    QPushButton *btnHome;
    QPushButton *btnBack;
    QPushButton *btnSkullPA;
    QPushButton *btnSkullLAT;
    QPushButton *btnSkullTowne;
    QWidget *spineViewPage;
    QLabel *background_3;
    QPushButton *btnHome_2;
    QPushButton *btnBack_2;
    QPushButton *btnSpineCSpine;
    QPushButton *btnSpineTSpine;
    QPushButton *btnSpineLSpine;
    QWidget *ribsViewPage;
    QLabel *background_4;
    QPushButton *btnHome_3;
    QPushButton *btnBack_3;
    QPushButton *btnRibsThoraxAP;
    QPushButton *btnRibsThoraxLAT;
    QPushButton *btnRibsAbdAP;
    QPushButton *btnRibsAbdLAT;
    QWidget *chestViewPage;
    QLabel *background_5;
    QPushButton *btnHome_4;
    QPushButton *btnBack_4;
    QPushButton *btnChestPA;
    QPushButton *btnChestLAT;
    QPushButton *btnChestSupinePA;
    QPushButton *btnChestSupineLAT;
    QWidget *uExtViewPage;
    QLabel *background_6;
    QPushButton *btnHome_5;
    QPushButton *btnBack_5;
    QPushButton *btnUExtShoulder;
    QPushButton *btnUExtHumerus;
    QPushButton *btnUExtForearm;
    QPushButton *btnUExtFingers;
    QWidget *lExtViewPage;
    QLabel *background_7;
    QPushButton *btnHome_6;
    QPushButton *btnBack_6;
    QPushButton *btnLExtFemur;
    QPushButton *btnLExtKnee;
    QPushButton *btnLExtAnkle;
    QPushButton *btnLExtToes;
    QWidget *abdomenViewPage;
    QLabel *background_8;
    QPushButton *btnHome_7;
    QPushButton *btnBack_7;
    QPushButton *btnAbdomenProneAP;
    QPushButton *btnAbdomenProneLAT;
    QPushButton *btnAbdomenStandAP;
    QPushButton *btnAbdomenStandLAT;
    QWidget *skullPaViewPage;
    QLabel *background_9;
    QPushButton *btnHome_9;
    QPushButton *btnBack_8;
    QWidget *skullLatViewPage;
    QLabel *background_10;
    QPushButton *btnHome_8;
    QPushButton *btnBack_9;
    QWidget *skullTowneViewPage;
    QLabel *background_11;
    QPushButton *btnHome_10;
    QPushButton *btnBack_10;
    QWidget *spineCSpineViewPage;
    QLabel *background_12;
    QPushButton *btnHome_11;
    QPushButton *btnBack_11;
    QPushButton *btnSpineCSpineAP;
    QPushButton *btnSpineCSpineLAT;
    QPushButton *btnSpineCSpineOblique;
    QWidget *spineTSpineViewPage;
    QLabel *background_13;
    QPushButton *btnHome_12;
    QPushButton *btnBack_12;
    QPushButton *btnSpineTSpineAP;
    QPushButton *btnSpineTSpineLAT;
    QPushButton *btnSpineTSpineSternAP;
    QPushButton *btnSpineTSpineSternLAT;
    QWidget *spineLSpineViewPage;
    QLabel *background_14;
    QPushButton *btnHome_13;
    QPushButton *btnBack_13;
    QPushButton *btnSpineLSpineAP;
    QPushButton *btnSpineLSpineLAT;
    QPushButton *btnSpineLSpineOblique;
    QPushButton *btnSpineLSpinePelvis;
    QWidget *spineCSpineApViewPage;
    QLabel *background_15;
    QPushButton *btnHome_14;
    QPushButton *btnBack_14;
    QPushButton *pushButtonDELETE;
    QWidget *spineCSpineLatViewPage;
    QLabel *background_16;
    QPushButton *btnHome_15;
    QPushButton *btnBack_15;
    QPushButton *pushButton_2DELETE;
    QWidget *spineCSpineObliqueViewPage;
    QLabel *background_17;
    QPushButton *btnHome_16;
    QPushButton *btnBack_16;
    QPushButton *pushButton_3DELETE;
    QWidget *spineTSpineApViewPage;
    QLabel *background_18;
    QPushButton *btnHome_17;
    QPushButton *btnBack_17;
    QPushButton *pushButtonDELETE_2;
    QWidget *spineTSpineLatViewPage;
    QLabel *background_19;
    QPushButton *btnHome_18;
    QPushButton *btnBack_18;
    QPushButton *pushButtonDELETE_3;
    QWidget *spineTSpineSternApViewPage;
    QLabel *background_20;
    QPushButton *btnHome_19;
    QPushButton *btnBack_19;
    QPushButton *pushButtonDELETE_4;
    QWidget *spineTSpineSternLatViewPage;
    QLabel *background_21;
    QPushButton *btnHome_20;
    QPushButton *btnBack_20;
    QPushButton *pushButtonDELETE_5;
    QWidget *spineLSpineApViewPage;
    QLabel *background_22;
    QPushButton *pushButtonDELETE_6;
    QPushButton *btnHome_21;
    QPushButton *btnBack_21;
    QWidget *spineLSpineLatViewPage;
    QLabel *background_23;
    QPushButton *pushButtonDELETE_7;
    QPushButton *btnHome_22;
    QPushButton *btnBack_22;
    QWidget *spineLSpineObliqueViewPage;
    QLabel *background_24;
    QPushButton *pushButtonDELETE_8;
    QPushButton *btnHome_23;
    QPushButton *btnBack_23;
    QWidget *spineLSpinePelvisViewPage;
    QLabel *background_25;
    QPushButton *pushButtonDELETE_9;
    QPushButton *btnHome_24;
    QPushButton *btnBack_24;
    QWidget *ribsThoraxApViewPage;
    QLabel *background_26;
    QPushButton *btnHome_25;
    QPushButton *btnBack_25;
    QPushButton *pushButtonDELETE_10;
    QWidget *ribsThoraxLatViewPage;
    QLabel *background_27;
    QPushButton *btnHome_26;
    QPushButton *btnBack_26;
    QPushButton *pushButtonDELETE_11;
    QWidget *ribsAbdApViewPage;
    QLabel *background_28;
    QPushButton *btnHome_27;
    QPushButton *btnBack_27;
    QPushButton *pushButtonDELETE_12;
    QWidget *ribsAbdLatViewPage;
    QLabel *background_29;
    QPushButton *btnHome_28;
    QPushButton *btnBack_28;
    QPushButton *pushButtonDELETE_13;
    QWidget *chestPaViewPage;
    QLabel *background_30;
    QPushButton *pushButtonDELETE_14;
    QPushButton *btnHome_29;
    QPushButton *btnBack_29;
    QWidget *chestLatViewPage;
    QLabel *background_31;
    QPushButton *pushButtonDELETE_15;
    QPushButton *btnHome_30;
    QPushButton *btnBack_30;
    QWidget *chestSupinePaViewPage;
    QLabel *background_32;
    QPushButton *pushButtonDELETE_16;
    QPushButton *btnHome_31;
    QPushButton *btnBack_31;
    QWidget *chestSupineLatViewPage;
    QLabel *background_33;
    QPushButton *pushButtonDELETE_17;
    QPushButton *btnHome_32;
    QPushButton *btnBack_32;
    QWidget *uExtShoulderViewPage;
    QLabel *background_34;
    QPushButton *pushButtonDELETE_18;
    QPushButton *btnHome_33;
    QPushButton *btnBack_33;
    QWidget *uExtHumerusViewPage;
    QLabel *background_35;
    QPushButton *pushButtonDELETE_19;
    QPushButton *btnHome_34;
    QPushButton *btnBack_34;
    QWidget *uExtForearmViewPage;
    QLabel *background_36;
    QPushButton *pushButtonDELETE_20;
    QPushButton *btnHome_35;
    QPushButton *btnBack_35;
    QWidget *uExtFingersViewPage;
    QLabel *background_37;
    QPushButton *pushButtonDELETE_21;
    QPushButton *btnHome_36;
    QPushButton *btnBack_36;
    QWidget *lExtFemurViewPage;
    QLabel *background_38;
    QPushButton *pushButtonDELETE_22;
    QPushButton *btnHome_37;
    QPushButton *btnBack_37;
    QWidget *lExtKneeViewPage;
    QLabel *background_39;
    QPushButton *pushButtonDELETE_23;
    QPushButton *btnHome_38;
    QPushButton *btnBack_38;
    QWidget *lExtAnkleViewPage;
    QLabel *background_40;
    QPushButton *pushButtonDELETE_24;
    QPushButton *btnHome_39;
    QPushButton *btnBack_39;
    QWidget *lExtToesViewPage;
    QLabel *background_41;
    QPushButton *pushButtonDELETE_25;
    QPushButton *btnHome_40;
    QPushButton *btnBack_40;
    QWidget *abdomenProneApViewPage;
    QLabel *background_42;
    QPushButton *pushButtonDELETE_26;
    QPushButton *btnHome_41;
    QPushButton *btnBack_41;
    QWidget *abdomenProneLatViewPage;
    QLabel *background_43;
    QPushButton *pushButtonDELETE_27;
    QPushButton *btnHome_42;
    QPushButton *btnBack_42;
    QWidget *abdomenStandApViewPage;
    QLabel *background_44;
    QPushButton *pushButtonDELETE_28;
    QPushButton *btnHome_43;
    QPushButton *btnBack_43;
    QWidget *abdomenStandLatViewPage;
    QLabel *background_45;
    QPushButton *pushButtonDELETE_29;
    QPushButton *btnHome_44;
    QPushButton *btnBack_44;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1024, 600);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        stackedWidget = new QStackedWidget(centralwidget);
        stackedWidget->setObjectName(QString::fromUtf8("stackedWidget"));
        stackedWidget->setGeometry(QRect(0, 0, 1024, 600));
        mainBodyPage = new QWidget();
        mainBodyPage->setObjectName(QString::fromUtf8("mainBodyPage"));
        background = new QLabel(mainBodyPage);
        background->setObjectName(QString::fromUtf8("background"));
        background->setGeometry(QRect(0, 0, 1024, 600));
        background->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain2.png")));
        btnSkull = new QPushButton(mainBodyPage);
        btnSkull->setObjectName(QString::fromUtf8("btnSkull"));
        btnSkull->setGeometry(QRect(94, 80, 200, 75));
        btnSkull->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnSkull.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnSkullClicked.png);\n"
"}"));
        btnSpine = new QPushButton(mainBodyPage);
        btnSpine->setObjectName(QString::fromUtf8("btnSpine"));
        btnSpine->setGeometry(QRect(730, 80, 200, 75));
        btnSpine->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnSpine.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnSpineClicked.png);\n"
"}"));
        btnRibs = new QPushButton(mainBodyPage);
        btnRibs->setObjectName(QString::fromUtf8("btnRibs"));
        btnRibs->setGeometry(QRect(94, 170, 200, 75));
        btnRibs->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnRibs.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnRibsClicked.png);\n"
"}"));
        btnChest = new QPushButton(mainBodyPage);
        btnChest->setObjectName(QString::fromUtf8("btnChest"));
        btnChest->setGeometry(QRect(730, 170, 200, 75));
        btnChest->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnChest.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnChestClicked.png);\n"
"}"));
        btnUExt = new QPushButton(mainBodyPage);
        btnUExt->setObjectName(QString::fromUtf8("btnUExt"));
        btnUExt->setGeometry(QRect(94, 260, 200, 75));
        btnUExt->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnUExt.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnUExtClicked.png);\n"
"}"));
        btnLExt = new QPushButton(mainBodyPage);
        btnLExt->setObjectName(QString::fromUtf8("btnLExt"));
        btnLExt->setGeometry(QRect(730, 260, 200, 75));
        btnLExt->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnLExt.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnLExtClicked.png);\n"
"}"));
        btnAbdomen = new QPushButton(mainBodyPage);
        btnAbdomen->setObjectName(QString::fromUtf8("btnAbdomen"));
        btnAbdomen->setGeometry(QRect(94, 350, 300, 75));
        btnAbdomen->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnAbdomen.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnAbdomenClicked.png);\n"
"}"));
        bodyViewImage = new QLabel(mainBodyPage);
        bodyViewImage->setObjectName(QString::fromUtf8("bodyViewImage"));
        bodyViewImage->setGeometry(QRect(368, 60, 300, 480));
        bodyViewImage->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bvMainBodySkele.png")));
        stackedWidget->addWidget(mainBodyPage);
        skullViewPage = new QWidget();
        skullViewPage->setObjectName(QString::fromUtf8("skullViewPage"));
        background_2 = new QLabel(skullViewPage);
        background_2->setObjectName(QString::fromUtf8("background_2"));
        background_2->setGeometry(QRect(0, 0, 1024, 600));
        background_2->setStyleSheet(QString::fromUtf8(""));
        background_2->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain2.png")));
        btnHome = new QPushButton(skullViewPage);
        btnHome->setObjectName(QString::fromUtf8("btnHome"));
        btnHome->setGeometry(QRect(740, 470, 200, 75));
        btnHome->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack = new QPushButton(skullViewPage);
        btnBack->setObjectName(QString::fromUtf8("btnBack"));
        btnBack->setGeometry(QRect(84, 470, 200, 75));
        btnBack->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnSkullPA = new QPushButton(skullViewPage);
        btnSkullPA->setObjectName(QString::fromUtf8("btnSkullPA"));
        btnSkullPA->setGeometry(QRect(95, 60, 250, 200));
        btnSkullPA->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnSkullPA.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnSkullPAClicked.png);\n"
"}"));
        btnSkullLAT = new QPushButton(skullViewPage);
        btnSkullLAT->setObjectName(QString::fromUtf8("btnSkullLAT"));
        btnSkullLAT->setGeometry(QRect(388, 60, 250, 200));
        btnSkullLAT->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnSkullLAT.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnSkullLATClicked.png);\n"
"}"));
        btnSkullTowne = new QPushButton(skullViewPage);
        btnSkullTowne->setObjectName(QString::fromUtf8("btnSkullTowne"));
        btnSkullTowne->setGeometry(QRect(680, 60, 250, 200));
        btnSkullTowne->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnSkullTowne.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnSkullTowneClicked.png);\n"
"}"));
        stackedWidget->addWidget(skullViewPage);
        spineViewPage = new QWidget();
        spineViewPage->setObjectName(QString::fromUtf8("spineViewPage"));
        background_3 = new QLabel(spineViewPage);
        background_3->setObjectName(QString::fromUtf8("background_3"));
        background_3->setGeometry(QRect(0, 0, 1024, 600));
        background_3->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_2 = new QPushButton(spineViewPage);
        btnHome_2->setObjectName(QString::fromUtf8("btnHome_2"));
        btnHome_2->setGeometry(QRect(740, 470, 200, 75));
        btnHome_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_2 = new QPushButton(spineViewPage);
        btnBack_2->setObjectName(QString::fromUtf8("btnBack_2"));
        btnBack_2->setGeometry(QRect(480, 470, 200, 75));
        btnBack_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnSpineCSpine = new QPushButton(spineViewPage);
        btnSpineCSpine->setObjectName(QString::fromUtf8("btnSpineCSpine"));
        btnSpineCSpine->setGeometry(QRect(560, 110, 80, 23));
        btnSpineTSpine = new QPushButton(spineViewPage);
        btnSpineTSpine->setObjectName(QString::fromUtf8("btnSpineTSpine"));
        btnSpineTSpine->setGeometry(QRect(560, 150, 80, 23));
        btnSpineLSpine = new QPushButton(spineViewPage);
        btnSpineLSpine->setObjectName(QString::fromUtf8("btnSpineLSpine"));
        btnSpineLSpine->setGeometry(QRect(560, 200, 80, 23));
        stackedWidget->addWidget(spineViewPage);
        ribsViewPage = new QWidget();
        ribsViewPage->setObjectName(QString::fromUtf8("ribsViewPage"));
        background_4 = new QLabel(ribsViewPage);
        background_4->setObjectName(QString::fromUtf8("background_4"));
        background_4->setGeometry(QRect(0, 0, 1024, 600));
        background_4->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_3 = new QPushButton(ribsViewPage);
        btnHome_3->setObjectName(QString::fromUtf8("btnHome_3"));
        btnHome_3->setGeometry(QRect(740, 470, 200, 75));
        btnHome_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_3 = new QPushButton(ribsViewPage);
        btnBack_3->setObjectName(QString::fromUtf8("btnBack_3"));
        btnBack_3->setGeometry(QRect(480, 470, 200, 75));
        btnBack_3->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnRibsThoraxAP = new QPushButton(ribsViewPage);
        btnRibsThoraxAP->setObjectName(QString::fromUtf8("btnRibsThoraxAP"));
        btnRibsThoraxAP->setGeometry(QRect(640, 100, 80, 23));
        btnRibsThoraxLAT = new QPushButton(ribsViewPage);
        btnRibsThoraxLAT->setObjectName(QString::fromUtf8("btnRibsThoraxLAT"));
        btnRibsThoraxLAT->setGeometry(QRect(640, 150, 80, 23));
        btnRibsAbdAP = new QPushButton(ribsViewPage);
        btnRibsAbdAP->setObjectName(QString::fromUtf8("btnRibsAbdAP"));
        btnRibsAbdAP->setGeometry(QRect(640, 200, 80, 23));
        btnRibsAbdLAT = new QPushButton(ribsViewPage);
        btnRibsAbdLAT->setObjectName(QString::fromUtf8("btnRibsAbdLAT"));
        btnRibsAbdLAT->setGeometry(QRect(640, 240, 80, 23));
        stackedWidget->addWidget(ribsViewPage);
        chestViewPage = new QWidget();
        chestViewPage->setObjectName(QString::fromUtf8("chestViewPage"));
        background_5 = new QLabel(chestViewPage);
        background_5->setObjectName(QString::fromUtf8("background_5"));
        background_5->setGeometry(QRect(0, 0, 1024, 600));
        background_5->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_4 = new QPushButton(chestViewPage);
        btnHome_4->setObjectName(QString::fromUtf8("btnHome_4"));
        btnHome_4->setGeometry(QRect(740, 470, 200, 75));
        btnHome_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_4 = new QPushButton(chestViewPage);
        btnBack_4->setObjectName(QString::fromUtf8("btnBack_4"));
        btnBack_4->setGeometry(QRect(480, 470, 200, 75));
        btnBack_4->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnChestPA = new QPushButton(chestViewPage);
        btnChestPA->setObjectName(QString::fromUtf8("btnChestPA"));
        btnChestPA->setGeometry(QRect(630, 150, 80, 23));
        btnChestLAT = new QPushButton(chestViewPage);
        btnChestLAT->setObjectName(QString::fromUtf8("btnChestLAT"));
        btnChestLAT->setGeometry(QRect(630, 210, 80, 23));
        btnChestSupinePA = new QPushButton(chestViewPage);
        btnChestSupinePA->setObjectName(QString::fromUtf8("btnChestSupinePA"));
        btnChestSupinePA->setGeometry(QRect(630, 270, 80, 23));
        btnChestSupineLAT = new QPushButton(chestViewPage);
        btnChestSupineLAT->setObjectName(QString::fromUtf8("btnChestSupineLAT"));
        btnChestSupineLAT->setGeometry(QRect(630, 320, 80, 23));
        stackedWidget->addWidget(chestViewPage);
        uExtViewPage = new QWidget();
        uExtViewPage->setObjectName(QString::fromUtf8("uExtViewPage"));
        background_6 = new QLabel(uExtViewPage);
        background_6->setObjectName(QString::fromUtf8("background_6"));
        background_6->setGeometry(QRect(0, 0, 1024, 600));
        background_6->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_5 = new QPushButton(uExtViewPage);
        btnHome_5->setObjectName(QString::fromUtf8("btnHome_5"));
        btnHome_5->setGeometry(QRect(740, 470, 200, 75));
        btnHome_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_5 = new QPushButton(uExtViewPage);
        btnBack_5->setObjectName(QString::fromUtf8("btnBack_5"));
        btnBack_5->setGeometry(QRect(480, 470, 200, 75));
        btnBack_5->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnUExtShoulder = new QPushButton(uExtViewPage);
        btnUExtShoulder->setObjectName(QString::fromUtf8("btnUExtShoulder"));
        btnUExtShoulder->setGeometry(QRect(640, 90, 80, 23));
        btnUExtHumerus = new QPushButton(uExtViewPage);
        btnUExtHumerus->setObjectName(QString::fromUtf8("btnUExtHumerus"));
        btnUExtHumerus->setGeometry(QRect(640, 140, 80, 23));
        btnUExtForearm = new QPushButton(uExtViewPage);
        btnUExtForearm->setObjectName(QString::fromUtf8("btnUExtForearm"));
        btnUExtForearm->setGeometry(QRect(640, 180, 80, 23));
        btnUExtFingers = new QPushButton(uExtViewPage);
        btnUExtFingers->setObjectName(QString::fromUtf8("btnUExtFingers"));
        btnUExtFingers->setGeometry(QRect(640, 220, 80, 23));
        stackedWidget->addWidget(uExtViewPage);
        lExtViewPage = new QWidget();
        lExtViewPage->setObjectName(QString::fromUtf8("lExtViewPage"));
        background_7 = new QLabel(lExtViewPage);
        background_7->setObjectName(QString::fromUtf8("background_7"));
        background_7->setGeometry(QRect(0, 0, 1024, 600));
        background_7->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_6 = new QPushButton(lExtViewPage);
        btnHome_6->setObjectName(QString::fromUtf8("btnHome_6"));
        btnHome_6->setGeometry(QRect(740, 470, 200, 75));
        btnHome_6->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_6 = new QPushButton(lExtViewPage);
        btnBack_6->setObjectName(QString::fromUtf8("btnBack_6"));
        btnBack_6->setGeometry(QRect(480, 470, 200, 75));
        btnBack_6->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnLExtFemur = new QPushButton(lExtViewPage);
        btnLExtFemur->setObjectName(QString::fromUtf8("btnLExtFemur"));
        btnLExtFemur->setGeometry(QRect(660, 100, 80, 23));
        btnLExtKnee = new QPushButton(lExtViewPage);
        btnLExtKnee->setObjectName(QString::fromUtf8("btnLExtKnee"));
        btnLExtKnee->setGeometry(QRect(660, 140, 80, 23));
        btnLExtAnkle = new QPushButton(lExtViewPage);
        btnLExtAnkle->setObjectName(QString::fromUtf8("btnLExtAnkle"));
        btnLExtAnkle->setGeometry(QRect(660, 190, 80, 23));
        btnLExtToes = new QPushButton(lExtViewPage);
        btnLExtToes->setObjectName(QString::fromUtf8("btnLExtToes"));
        btnLExtToes->setGeometry(QRect(660, 230, 80, 23));
        stackedWidget->addWidget(lExtViewPage);
        abdomenViewPage = new QWidget();
        abdomenViewPage->setObjectName(QString::fromUtf8("abdomenViewPage"));
        background_8 = new QLabel(abdomenViewPage);
        background_8->setObjectName(QString::fromUtf8("background_8"));
        background_8->setGeometry(QRect(0, 0, 1024, 600));
        background_8->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_7 = new QPushButton(abdomenViewPage);
        btnHome_7->setObjectName(QString::fromUtf8("btnHome_7"));
        btnHome_7->setGeometry(QRect(740, 470, 200, 75));
        btnHome_7->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_7 = new QPushButton(abdomenViewPage);
        btnBack_7->setObjectName(QString::fromUtf8("btnBack_7"));
        btnBack_7->setGeometry(QRect(480, 470, 200, 75));
        btnBack_7->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnAbdomenProneAP = new QPushButton(abdomenViewPage);
        btnAbdomenProneAP->setObjectName(QString::fromUtf8("btnAbdomenProneAP"));
        btnAbdomenProneAP->setGeometry(QRect(670, 90, 80, 23));
        btnAbdomenProneLAT = new QPushButton(abdomenViewPage);
        btnAbdomenProneLAT->setObjectName(QString::fromUtf8("btnAbdomenProneLAT"));
        btnAbdomenProneLAT->setGeometry(QRect(670, 150, 80, 23));
        btnAbdomenStandAP = new QPushButton(abdomenViewPage);
        btnAbdomenStandAP->setObjectName(QString::fromUtf8("btnAbdomenStandAP"));
        btnAbdomenStandAP->setGeometry(QRect(670, 200, 80, 23));
        btnAbdomenStandLAT = new QPushButton(abdomenViewPage);
        btnAbdomenStandLAT->setObjectName(QString::fromUtf8("btnAbdomenStandLAT"));
        btnAbdomenStandLAT->setGeometry(QRect(670, 250, 80, 23));
        stackedWidget->addWidget(abdomenViewPage);
        skullPaViewPage = new QWidget();
        skullPaViewPage->setObjectName(QString::fromUtf8("skullPaViewPage"));
        background_9 = new QLabel(skullPaViewPage);
        background_9->setObjectName(QString::fromUtf8("background_9"));
        background_9->setGeometry(QRect(0, 0, 1024, 600));
        background_9->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_9 = new QPushButton(skullPaViewPage);
        btnHome_9->setObjectName(QString::fromUtf8("btnHome_9"));
        btnHome_9->setGeometry(QRect(740, 470, 200, 75));
        btnHome_9->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_8 = new QPushButton(skullPaViewPage);
        btnBack_8->setObjectName(QString::fromUtf8("btnBack_8"));
        btnBack_8->setGeometry(QRect(480, 470, 200, 75));
        btnBack_8->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(skullPaViewPage);
        skullLatViewPage = new QWidget();
        skullLatViewPage->setObjectName(QString::fromUtf8("skullLatViewPage"));
        background_10 = new QLabel(skullLatViewPage);
        background_10->setObjectName(QString::fromUtf8("background_10"));
        background_10->setGeometry(QRect(0, 0, 1024, 600));
        background_10->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_8 = new QPushButton(skullLatViewPage);
        btnHome_8->setObjectName(QString::fromUtf8("btnHome_8"));
        btnHome_8->setGeometry(QRect(740, 470, 200, 75));
        btnHome_8->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_9 = new QPushButton(skullLatViewPage);
        btnBack_9->setObjectName(QString::fromUtf8("btnBack_9"));
        btnBack_9->setGeometry(QRect(480, 470, 200, 75));
        btnBack_9->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(skullLatViewPage);
        skullTowneViewPage = new QWidget();
        skullTowneViewPage->setObjectName(QString::fromUtf8("skullTowneViewPage"));
        background_11 = new QLabel(skullTowneViewPage);
        background_11->setObjectName(QString::fromUtf8("background_11"));
        background_11->setGeometry(QRect(0, 0, 1024, 600));
        background_11->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        background_11->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_10 = new QPushButton(skullTowneViewPage);
        btnHome_10->setObjectName(QString::fromUtf8("btnHome_10"));
        btnHome_10->setGeometry(QRect(740, 470, 200, 75));
        btnHome_10->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_10 = new QPushButton(skullTowneViewPage);
        btnBack_10->setObjectName(QString::fromUtf8("btnBack_10"));
        btnBack_10->setGeometry(QRect(480, 470, 200, 75));
        btnBack_10->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(skullTowneViewPage);
        spineCSpineViewPage = new QWidget();
        spineCSpineViewPage->setObjectName(QString::fromUtf8("spineCSpineViewPage"));
        background_12 = new QLabel(spineCSpineViewPage);
        background_12->setObjectName(QString::fromUtf8("background_12"));
        background_12->setGeometry(QRect(0, 0, 1024, 600));
        background_12->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_11 = new QPushButton(spineCSpineViewPage);
        btnHome_11->setObjectName(QString::fromUtf8("btnHome_11"));
        btnHome_11->setGeometry(QRect(740, 470, 200, 75));
        btnHome_11->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_11 = new QPushButton(spineCSpineViewPage);
        btnBack_11->setObjectName(QString::fromUtf8("btnBack_11"));
        btnBack_11->setGeometry(QRect(480, 470, 200, 75));
        btnBack_11->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnSpineCSpineAP = new QPushButton(spineCSpineViewPage);
        btnSpineCSpineAP->setObjectName(QString::fromUtf8("btnSpineCSpineAP"));
        btnSpineCSpineAP->setGeometry(QRect(650, 110, 80, 23));
        btnSpineCSpineLAT = new QPushButton(spineCSpineViewPage);
        btnSpineCSpineLAT->setObjectName(QString::fromUtf8("btnSpineCSpineLAT"));
        btnSpineCSpineLAT->setGeometry(QRect(650, 170, 80, 23));
        btnSpineCSpineOblique = new QPushButton(spineCSpineViewPage);
        btnSpineCSpineOblique->setObjectName(QString::fromUtf8("btnSpineCSpineOblique"));
        btnSpineCSpineOblique->setGeometry(QRect(650, 240, 80, 23));
        stackedWidget->addWidget(spineCSpineViewPage);
        spineTSpineViewPage = new QWidget();
        spineTSpineViewPage->setObjectName(QString::fromUtf8("spineTSpineViewPage"));
        background_13 = new QLabel(spineTSpineViewPage);
        background_13->setObjectName(QString::fromUtf8("background_13"));
        background_13->setGeometry(QRect(0, 0, 1024, 600));
        background_13->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_12 = new QPushButton(spineTSpineViewPage);
        btnHome_12->setObjectName(QString::fromUtf8("btnHome_12"));
        btnHome_12->setGeometry(QRect(740, 470, 200, 75));
        btnHome_12->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_12 = new QPushButton(spineTSpineViewPage);
        btnBack_12->setObjectName(QString::fromUtf8("btnBack_12"));
        btnBack_12->setGeometry(QRect(480, 470, 200, 75));
        btnBack_12->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnSpineTSpineAP = new QPushButton(spineTSpineViewPage);
        btnSpineTSpineAP->setObjectName(QString::fromUtf8("btnSpineTSpineAP"));
        btnSpineTSpineAP->setGeometry(QRect(670, 110, 80, 23));
        btnSpineTSpineLAT = new QPushButton(spineTSpineViewPage);
        btnSpineTSpineLAT->setObjectName(QString::fromUtf8("btnSpineTSpineLAT"));
        btnSpineTSpineLAT->setGeometry(QRect(670, 160, 80, 23));
        btnSpineTSpineSternAP = new QPushButton(spineTSpineViewPage);
        btnSpineTSpineSternAP->setObjectName(QString::fromUtf8("btnSpineTSpineSternAP"));
        btnSpineTSpineSternAP->setGeometry(QRect(670, 210, 80, 23));
        btnSpineTSpineSternLAT = new QPushButton(spineTSpineViewPage);
        btnSpineTSpineSternLAT->setObjectName(QString::fromUtf8("btnSpineTSpineSternLAT"));
        btnSpineTSpineSternLAT->setGeometry(QRect(670, 250, 80, 23));
        stackedWidget->addWidget(spineTSpineViewPage);
        spineLSpineViewPage = new QWidget();
        spineLSpineViewPage->setObjectName(QString::fromUtf8("spineLSpineViewPage"));
        background_14 = new QLabel(spineLSpineViewPage);
        background_14->setObjectName(QString::fromUtf8("background_14"));
        background_14->setGeometry(QRect(0, 0, 1024, 600));
        background_14->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_13 = new QPushButton(spineLSpineViewPage);
        btnHome_13->setObjectName(QString::fromUtf8("btnHome_13"));
        btnHome_13->setGeometry(QRect(740, 470, 200, 75));
        btnHome_13->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_13 = new QPushButton(spineLSpineViewPage);
        btnBack_13->setObjectName(QString::fromUtf8("btnBack_13"));
        btnBack_13->setGeometry(QRect(480, 470, 200, 75));
        btnBack_13->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        btnSpineLSpineAP = new QPushButton(spineLSpineViewPage);
        btnSpineLSpineAP->setObjectName(QString::fromUtf8("btnSpineLSpineAP"));
        btnSpineLSpineAP->setGeometry(QRect(670, 120, 80, 23));
        btnSpineLSpineLAT = new QPushButton(spineLSpineViewPage);
        btnSpineLSpineLAT->setObjectName(QString::fromUtf8("btnSpineLSpineLAT"));
        btnSpineLSpineLAT->setGeometry(QRect(670, 170, 80, 23));
        btnSpineLSpineOblique = new QPushButton(spineLSpineViewPage);
        btnSpineLSpineOblique->setObjectName(QString::fromUtf8("btnSpineLSpineOblique"));
        btnSpineLSpineOblique->setGeometry(QRect(670, 220, 80, 23));
        btnSpineLSpinePelvis = new QPushButton(spineLSpineViewPage);
        btnSpineLSpinePelvis->setObjectName(QString::fromUtf8("btnSpineLSpinePelvis"));
        btnSpineLSpinePelvis->setGeometry(QRect(670, 270, 80, 23));
        stackedWidget->addWidget(spineLSpineViewPage);
        spineCSpineApViewPage = new QWidget();
        spineCSpineApViewPage->setObjectName(QString::fromUtf8("spineCSpineApViewPage"));
        background_15 = new QLabel(spineCSpineApViewPage);
        background_15->setObjectName(QString::fromUtf8("background_15"));
        background_15->setGeometry(QRect(0, 0, 1024, 600));
        background_15->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_14 = new QPushButton(spineCSpineApViewPage);
        btnHome_14->setObjectName(QString::fromUtf8("btnHome_14"));
        btnHome_14->setGeometry(QRect(740, 470, 200, 75));
        btnHome_14->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_14 = new QPushButton(spineCSpineApViewPage);
        btnBack_14->setObjectName(QString::fromUtf8("btnBack_14"));
        btnBack_14->setGeometry(QRect(480, 470, 200, 75));
        btnBack_14->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE = new QPushButton(spineCSpineApViewPage);
        pushButtonDELETE->setObjectName(QString::fromUtf8("pushButtonDELETE"));
        pushButtonDELETE->setGeometry(QRect(630, 190, 80, 23));
        stackedWidget->addWidget(spineCSpineApViewPage);
        spineCSpineLatViewPage = new QWidget();
        spineCSpineLatViewPage->setObjectName(QString::fromUtf8("spineCSpineLatViewPage"));
        background_16 = new QLabel(spineCSpineLatViewPage);
        background_16->setObjectName(QString::fromUtf8("background_16"));
        background_16->setGeometry(QRect(0, 0, 1024, 600));
        background_16->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_15 = new QPushButton(spineCSpineLatViewPage);
        btnHome_15->setObjectName(QString::fromUtf8("btnHome_15"));
        btnHome_15->setGeometry(QRect(740, 470, 200, 75));
        btnHome_15->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_15 = new QPushButton(spineCSpineLatViewPage);
        btnBack_15->setObjectName(QString::fromUtf8("btnBack_15"));
        btnBack_15->setGeometry(QRect(480, 470, 200, 75));
        btnBack_15->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButton_2DELETE = new QPushButton(spineCSpineLatViewPage);
        pushButton_2DELETE->setObjectName(QString::fromUtf8("pushButton_2DELETE"));
        pushButton_2DELETE->setGeometry(QRect(580, 180, 80, 23));
        stackedWidget->addWidget(spineCSpineLatViewPage);
        spineCSpineObliqueViewPage = new QWidget();
        spineCSpineObliqueViewPage->setObjectName(QString::fromUtf8("spineCSpineObliqueViewPage"));
        background_17 = new QLabel(spineCSpineObliqueViewPage);
        background_17->setObjectName(QString::fromUtf8("background_17"));
        background_17->setGeometry(QRect(0, 0, 1024, 600));
        background_17->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_16 = new QPushButton(spineCSpineObliqueViewPage);
        btnHome_16->setObjectName(QString::fromUtf8("btnHome_16"));
        btnHome_16->setGeometry(QRect(740, 470, 200, 75));
        btnHome_16->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_16 = new QPushButton(spineCSpineObliqueViewPage);
        btnBack_16->setObjectName(QString::fromUtf8("btnBack_16"));
        btnBack_16->setGeometry(QRect(480, 470, 200, 75));
        btnBack_16->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButton_3DELETE = new QPushButton(spineCSpineObliqueViewPage);
        pushButton_3DELETE->setObjectName(QString::fromUtf8("pushButton_3DELETE"));
        pushButton_3DELETE->setGeometry(QRect(610, 200, 121, 23));
        stackedWidget->addWidget(spineCSpineObliqueViewPage);
        spineTSpineApViewPage = new QWidget();
        spineTSpineApViewPage->setObjectName(QString::fromUtf8("spineTSpineApViewPage"));
        background_18 = new QLabel(spineTSpineApViewPage);
        background_18->setObjectName(QString::fromUtf8("background_18"));
        background_18->setGeometry(QRect(0, 0, 1024, 600));
        background_18->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_17 = new QPushButton(spineTSpineApViewPage);
        btnHome_17->setObjectName(QString::fromUtf8("btnHome_17"));
        btnHome_17->setGeometry(QRect(740, 470, 200, 75));
        btnHome_17->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_17 = new QPushButton(spineTSpineApViewPage);
        btnBack_17->setObjectName(QString::fromUtf8("btnBack_17"));
        btnBack_17->setGeometry(QRect(480, 470, 200, 75));
        btnBack_17->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_2 = new QPushButton(spineTSpineApViewPage);
        pushButtonDELETE_2->setObjectName(QString::fromUtf8("pushButtonDELETE_2"));
        pushButtonDELETE_2->setGeometry(QRect(610, 190, 80, 23));
        stackedWidget->addWidget(spineTSpineApViewPage);
        spineTSpineLatViewPage = new QWidget();
        spineTSpineLatViewPage->setObjectName(QString::fromUtf8("spineTSpineLatViewPage"));
        background_19 = new QLabel(spineTSpineLatViewPage);
        background_19->setObjectName(QString::fromUtf8("background_19"));
        background_19->setGeometry(QRect(0, 0, 1024, 600));
        background_19->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_18 = new QPushButton(spineTSpineLatViewPage);
        btnHome_18->setObjectName(QString::fromUtf8("btnHome_18"));
        btnHome_18->setGeometry(QRect(740, 470, 200, 75));
        btnHome_18->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_18 = new QPushButton(spineTSpineLatViewPage);
        btnBack_18->setObjectName(QString::fromUtf8("btnBack_18"));
        btnBack_18->setGeometry(QRect(480, 470, 200, 75));
        btnBack_18->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_3 = new QPushButton(spineTSpineLatViewPage);
        pushButtonDELETE_3->setObjectName(QString::fromUtf8("pushButtonDELETE_3"));
        pushButtonDELETE_3->setGeometry(QRect(650, 210, 80, 23));
        stackedWidget->addWidget(spineTSpineLatViewPage);
        spineTSpineSternApViewPage = new QWidget();
        spineTSpineSternApViewPage->setObjectName(QString::fromUtf8("spineTSpineSternApViewPage"));
        background_20 = new QLabel(spineTSpineSternApViewPage);
        background_20->setObjectName(QString::fromUtf8("background_20"));
        background_20->setGeometry(QRect(0, 0, 1024, 600));
        background_20->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_19 = new QPushButton(spineTSpineSternApViewPage);
        btnHome_19->setObjectName(QString::fromUtf8("btnHome_19"));
        btnHome_19->setGeometry(QRect(740, 470, 200, 75));
        btnHome_19->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_19 = new QPushButton(spineTSpineSternApViewPage);
        btnBack_19->setObjectName(QString::fromUtf8("btnBack_19"));
        btnBack_19->setGeometry(QRect(480, 470, 200, 75));
        btnBack_19->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_4 = new QPushButton(spineTSpineSternApViewPage);
        pushButtonDELETE_4->setObjectName(QString::fromUtf8("pushButtonDELETE_4"));
        pushButtonDELETE_4->setGeometry(QRect(640, 200, 121, 23));
        stackedWidget->addWidget(spineTSpineSternApViewPage);
        spineTSpineSternLatViewPage = new QWidget();
        spineTSpineSternLatViewPage->setObjectName(QString::fromUtf8("spineTSpineSternLatViewPage"));
        background_21 = new QLabel(spineTSpineSternLatViewPage);
        background_21->setObjectName(QString::fromUtf8("background_21"));
        background_21->setGeometry(QRect(0, 0, 1024, 600));
        background_21->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_20 = new QPushButton(spineTSpineSternLatViewPage);
        btnHome_20->setObjectName(QString::fromUtf8("btnHome_20"));
        btnHome_20->setGeometry(QRect(740, 470, 200, 75));
        btnHome_20->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_20 = new QPushButton(spineTSpineSternLatViewPage);
        btnBack_20->setObjectName(QString::fromUtf8("btnBack_20"));
        btnBack_20->setGeometry(QRect(480, 470, 200, 75));
        btnBack_20->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_5 = new QPushButton(spineTSpineSternLatViewPage);
        pushButtonDELETE_5->setObjectName(QString::fromUtf8("pushButtonDELETE_5"));
        pushButtonDELETE_5->setGeometry(QRect(640, 230, 121, 23));
        stackedWidget->addWidget(spineTSpineSternLatViewPage);
        spineLSpineApViewPage = new QWidget();
        spineLSpineApViewPage->setObjectName(QString::fromUtf8("spineLSpineApViewPage"));
        background_22 = new QLabel(spineLSpineApViewPage);
        background_22->setObjectName(QString::fromUtf8("background_22"));
        background_22->setGeometry(QRect(0, 0, 1024, 600));
        background_22->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_6 = new QPushButton(spineLSpineApViewPage);
        pushButtonDELETE_6->setObjectName(QString::fromUtf8("pushButtonDELETE_6"));
        pushButtonDELETE_6->setGeometry(QRect(620, 140, 80, 23));
        btnHome_21 = new QPushButton(spineLSpineApViewPage);
        btnHome_21->setObjectName(QString::fromUtf8("btnHome_21"));
        btnHome_21->setGeometry(QRect(740, 470, 200, 75));
        btnHome_21->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_21 = new QPushButton(spineLSpineApViewPage);
        btnBack_21->setObjectName(QString::fromUtf8("btnBack_21"));
        btnBack_21->setGeometry(QRect(480, 470, 200, 75));
        btnBack_21->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(spineLSpineApViewPage);
        spineLSpineLatViewPage = new QWidget();
        spineLSpineLatViewPage->setObjectName(QString::fromUtf8("spineLSpineLatViewPage"));
        background_23 = new QLabel(spineLSpineLatViewPage);
        background_23->setObjectName(QString::fromUtf8("background_23"));
        background_23->setGeometry(QRect(0, 0, 1024, 600));
        background_23->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_7 = new QPushButton(spineLSpineLatViewPage);
        pushButtonDELETE_7->setObjectName(QString::fromUtf8("pushButtonDELETE_7"));
        pushButtonDELETE_7->setGeometry(QRect(660, 160, 80, 23));
        btnHome_22 = new QPushButton(spineLSpineLatViewPage);
        btnHome_22->setObjectName(QString::fromUtf8("btnHome_22"));
        btnHome_22->setGeometry(QRect(740, 470, 200, 75));
        btnHome_22->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_22 = new QPushButton(spineLSpineLatViewPage);
        btnBack_22->setObjectName(QString::fromUtf8("btnBack_22"));
        btnBack_22->setGeometry(QRect(480, 470, 200, 75));
        btnBack_22->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(spineLSpineLatViewPage);
        spineLSpineObliqueViewPage = new QWidget();
        spineLSpineObliqueViewPage->setObjectName(QString::fromUtf8("spineLSpineObliqueViewPage"));
        background_24 = new QLabel(spineLSpineObliqueViewPage);
        background_24->setObjectName(QString::fromUtf8("background_24"));
        background_24->setGeometry(QRect(0, 0, 1024, 600));
        background_24->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_8 = new QPushButton(spineLSpineObliqueViewPage);
        pushButtonDELETE_8->setObjectName(QString::fromUtf8("pushButtonDELETE_8"));
        pushButtonDELETE_8->setGeometry(QRect(600, 180, 181, 23));
        btnHome_23 = new QPushButton(spineLSpineObliqueViewPage);
        btnHome_23->setObjectName(QString::fromUtf8("btnHome_23"));
        btnHome_23->setGeometry(QRect(740, 470, 200, 75));
        btnHome_23->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_23 = new QPushButton(spineLSpineObliqueViewPage);
        btnBack_23->setObjectName(QString::fromUtf8("btnBack_23"));
        btnBack_23->setGeometry(QRect(480, 470, 200, 75));
        btnBack_23->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(spineLSpineObliqueViewPage);
        spineLSpinePelvisViewPage = new QWidget();
        spineLSpinePelvisViewPage->setObjectName(QString::fromUtf8("spineLSpinePelvisViewPage"));
        background_25 = new QLabel(spineLSpinePelvisViewPage);
        background_25->setObjectName(QString::fromUtf8("background_25"));
        background_25->setGeometry(QRect(0, 0, 1024, 600));
        background_25->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_9 = new QPushButton(spineLSpinePelvisViewPage);
        pushButtonDELETE_9->setObjectName(QString::fromUtf8("pushButtonDELETE_9"));
        pushButtonDELETE_9->setGeometry(QRect(620, 200, 151, 23));
        btnHome_24 = new QPushButton(spineLSpinePelvisViewPage);
        btnHome_24->setObjectName(QString::fromUtf8("btnHome_24"));
        btnHome_24->setGeometry(QRect(740, 470, 200, 75));
        btnHome_24->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_24 = new QPushButton(spineLSpinePelvisViewPage);
        btnBack_24->setObjectName(QString::fromUtf8("btnBack_24"));
        btnBack_24->setGeometry(QRect(480, 470, 200, 75));
        btnBack_24->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(spineLSpinePelvisViewPage);
        ribsThoraxApViewPage = new QWidget();
        ribsThoraxApViewPage->setObjectName(QString::fromUtf8("ribsThoraxApViewPage"));
        background_26 = new QLabel(ribsThoraxApViewPage);
        background_26->setObjectName(QString::fromUtf8("background_26"));
        background_26->setGeometry(QRect(0, 0, 1024, 600));
        background_26->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_25 = new QPushButton(ribsThoraxApViewPage);
        btnHome_25->setObjectName(QString::fromUtf8("btnHome_25"));
        btnHome_25->setGeometry(QRect(740, 470, 200, 75));
        btnHome_25->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_25 = new QPushButton(ribsThoraxApViewPage);
        btnBack_25->setObjectName(QString::fromUtf8("btnBack_25"));
        btnBack_25->setGeometry(QRect(480, 470, 200, 75));
        btnBack_25->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_10 = new QPushButton(ribsThoraxApViewPage);
        pushButtonDELETE_10->setObjectName(QString::fromUtf8("pushButtonDELETE_10"));
        pushButtonDELETE_10->setGeometry(QRect(580, 160, 151, 23));
        stackedWidget->addWidget(ribsThoraxApViewPage);
        ribsThoraxLatViewPage = new QWidget();
        ribsThoraxLatViewPage->setObjectName(QString::fromUtf8("ribsThoraxLatViewPage"));
        background_27 = new QLabel(ribsThoraxLatViewPage);
        background_27->setObjectName(QString::fromUtf8("background_27"));
        background_27->setGeometry(QRect(0, 0, 1024, 600));
        background_27->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_26 = new QPushButton(ribsThoraxLatViewPage);
        btnHome_26->setObjectName(QString::fromUtf8("btnHome_26"));
        btnHome_26->setGeometry(QRect(740, 470, 200, 75));
        btnHome_26->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_26 = new QPushButton(ribsThoraxLatViewPage);
        btnBack_26->setObjectName(QString::fromUtf8("btnBack_26"));
        btnBack_26->setGeometry(QRect(480, 470, 200, 75));
        btnBack_26->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_11 = new QPushButton(ribsThoraxLatViewPage);
        pushButtonDELETE_11->setObjectName(QString::fromUtf8("pushButtonDELETE_11"));
        pushButtonDELETE_11->setGeometry(QRect(580, 170, 161, 23));
        stackedWidget->addWidget(ribsThoraxLatViewPage);
        ribsAbdApViewPage = new QWidget();
        ribsAbdApViewPage->setObjectName(QString::fromUtf8("ribsAbdApViewPage"));
        background_28 = new QLabel(ribsAbdApViewPage);
        background_28->setObjectName(QString::fromUtf8("background_28"));
        background_28->setGeometry(QRect(0, 0, 1024, 600));
        background_28->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_27 = new QPushButton(ribsAbdApViewPage);
        btnHome_27->setObjectName(QString::fromUtf8("btnHome_27"));
        btnHome_27->setGeometry(QRect(740, 470, 200, 75));
        btnHome_27->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_27 = new QPushButton(ribsAbdApViewPage);
        btnBack_27->setObjectName(QString::fromUtf8("btnBack_27"));
        btnBack_27->setGeometry(QRect(480, 470, 200, 75));
        btnBack_27->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_12 = new QPushButton(ribsAbdApViewPage);
        pushButtonDELETE_12->setObjectName(QString::fromUtf8("pushButtonDELETE_12"));
        pushButtonDELETE_12->setGeometry(QRect(610, 190, 131, 23));
        stackedWidget->addWidget(ribsAbdApViewPage);
        ribsAbdLatViewPage = new QWidget();
        ribsAbdLatViewPage->setObjectName(QString::fromUtf8("ribsAbdLatViewPage"));
        background_29 = new QLabel(ribsAbdLatViewPage);
        background_29->setObjectName(QString::fromUtf8("background_29"));
        background_29->setGeometry(QRect(0, 0, 1024, 600));
        background_29->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        btnHome_28 = new QPushButton(ribsAbdLatViewPage);
        btnHome_28->setObjectName(QString::fromUtf8("btnHome_28"));
        btnHome_28->setGeometry(QRect(740, 470, 200, 75));
        btnHome_28->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_28 = new QPushButton(ribsAbdLatViewPage);
        btnBack_28->setObjectName(QString::fromUtf8("btnBack_28"));
        btnBack_28->setGeometry(QRect(480, 470, 200, 75));
        btnBack_28->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        pushButtonDELETE_13 = new QPushButton(ribsAbdLatViewPage);
        pushButtonDELETE_13->setObjectName(QString::fromUtf8("pushButtonDELETE_13"));
        pushButtonDELETE_13->setGeometry(QRect(590, 180, 121, 23));
        stackedWidget->addWidget(ribsAbdLatViewPage);
        chestPaViewPage = new QWidget();
        chestPaViewPage->setObjectName(QString::fromUtf8("chestPaViewPage"));
        background_30 = new QLabel(chestPaViewPage);
        background_30->setObjectName(QString::fromUtf8("background_30"));
        background_30->setGeometry(QRect(0, 0, 1024, 600));
        background_30->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_14 = new QPushButton(chestPaViewPage);
        pushButtonDELETE_14->setObjectName(QString::fromUtf8("pushButtonDELETE_14"));
        pushButtonDELETE_14->setGeometry(QRect(650, 150, 80, 23));
        btnHome_29 = new QPushButton(chestPaViewPage);
        btnHome_29->setObjectName(QString::fromUtf8("btnHome_29"));
        btnHome_29->setGeometry(QRect(740, 470, 200, 75));
        btnHome_29->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_29 = new QPushButton(chestPaViewPage);
        btnBack_29->setObjectName(QString::fromUtf8("btnBack_29"));
        btnBack_29->setGeometry(QRect(480, 470, 200, 75));
        btnBack_29->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(chestPaViewPage);
        chestLatViewPage = new QWidget();
        chestLatViewPage->setObjectName(QString::fromUtf8("chestLatViewPage"));
        background_31 = new QLabel(chestLatViewPage);
        background_31->setObjectName(QString::fromUtf8("background_31"));
        background_31->setGeometry(QRect(0, 0, 1024, 600));
        background_31->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_15 = new QPushButton(chestLatViewPage);
        pushButtonDELETE_15->setObjectName(QString::fromUtf8("pushButtonDELETE_15"));
        pushButtonDELETE_15->setGeometry(QRect(640, 170, 80, 23));
        btnHome_30 = new QPushButton(chestLatViewPage);
        btnHome_30->setObjectName(QString::fromUtf8("btnHome_30"));
        btnHome_30->setGeometry(QRect(740, 470, 200, 75));
        btnHome_30->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_30 = new QPushButton(chestLatViewPage);
        btnBack_30->setObjectName(QString::fromUtf8("btnBack_30"));
        btnBack_30->setGeometry(QRect(480, 470, 200, 75));
        btnBack_30->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(chestLatViewPage);
        chestSupinePaViewPage = new QWidget();
        chestSupinePaViewPage->setObjectName(QString::fromUtf8("chestSupinePaViewPage"));
        background_32 = new QLabel(chestSupinePaViewPage);
        background_32->setObjectName(QString::fromUtf8("background_32"));
        background_32->setGeometry(QRect(0, 0, 1024, 600));
        background_32->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_16 = new QPushButton(chestSupinePaViewPage);
        pushButtonDELETE_16->setObjectName(QString::fromUtf8("pushButtonDELETE_16"));
        pushButtonDELETE_16->setGeometry(QRect(680, 160, 161, 23));
        btnHome_31 = new QPushButton(chestSupinePaViewPage);
        btnHome_31->setObjectName(QString::fromUtf8("btnHome_31"));
        btnHome_31->setGeometry(QRect(740, 470, 200, 75));
        btnHome_31->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_31 = new QPushButton(chestSupinePaViewPage);
        btnBack_31->setObjectName(QString::fromUtf8("btnBack_31"));
        btnBack_31->setGeometry(QRect(480, 470, 200, 75));
        btnBack_31->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(chestSupinePaViewPage);
        chestSupineLatViewPage = new QWidget();
        chestSupineLatViewPage->setObjectName(QString::fromUtf8("chestSupineLatViewPage"));
        background_33 = new QLabel(chestSupineLatViewPage);
        background_33->setObjectName(QString::fromUtf8("background_33"));
        background_33->setGeometry(QRect(0, 0, 1024, 600));
        background_33->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_17 = new QPushButton(chestSupineLatViewPage);
        pushButtonDELETE_17->setObjectName(QString::fromUtf8("pushButtonDELETE_17"));
        pushButtonDELETE_17->setGeometry(QRect(660, 190, 171, 23));
        btnHome_32 = new QPushButton(chestSupineLatViewPage);
        btnHome_32->setObjectName(QString::fromUtf8("btnHome_32"));
        btnHome_32->setGeometry(QRect(740, 470, 200, 75));
        btnHome_32->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_32 = new QPushButton(chestSupineLatViewPage);
        btnBack_32->setObjectName(QString::fromUtf8("btnBack_32"));
        btnBack_32->setGeometry(QRect(480, 470, 200, 75));
        btnBack_32->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(chestSupineLatViewPage);
        uExtShoulderViewPage = new QWidget();
        uExtShoulderViewPage->setObjectName(QString::fromUtf8("uExtShoulderViewPage"));
        background_34 = new QLabel(uExtShoulderViewPage);
        background_34->setObjectName(QString::fromUtf8("background_34"));
        background_34->setGeometry(QRect(0, 0, 1024, 600));
        background_34->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_18 = new QPushButton(uExtShoulderViewPage);
        pushButtonDELETE_18->setObjectName(QString::fromUtf8("pushButtonDELETE_18"));
        pushButtonDELETE_18->setGeometry(QRect(660, 140, 111, 23));
        btnHome_33 = new QPushButton(uExtShoulderViewPage);
        btnHome_33->setObjectName(QString::fromUtf8("btnHome_33"));
        btnHome_33->setGeometry(QRect(740, 470, 200, 75));
        btnHome_33->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_33 = new QPushButton(uExtShoulderViewPage);
        btnBack_33->setObjectName(QString::fromUtf8("btnBack_33"));
        btnBack_33->setGeometry(QRect(480, 470, 200, 75));
        btnBack_33->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(uExtShoulderViewPage);
        uExtHumerusViewPage = new QWidget();
        uExtHumerusViewPage->setObjectName(QString::fromUtf8("uExtHumerusViewPage"));
        background_35 = new QLabel(uExtHumerusViewPage);
        background_35->setObjectName(QString::fromUtf8("background_35"));
        background_35->setGeometry(QRect(0, 0, 1024, 600));
        background_35->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_19 = new QPushButton(uExtHumerusViewPage);
        pushButtonDELETE_19->setObjectName(QString::fromUtf8("pushButtonDELETE_19"));
        pushButtonDELETE_19->setGeometry(QRect(610, 140, 121, 23));
        btnHome_34 = new QPushButton(uExtHumerusViewPage);
        btnHome_34->setObjectName(QString::fromUtf8("btnHome_34"));
        btnHome_34->setGeometry(QRect(740, 470, 200, 75));
        btnHome_34->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_34 = new QPushButton(uExtHumerusViewPage);
        btnBack_34->setObjectName(QString::fromUtf8("btnBack_34"));
        btnBack_34->setGeometry(QRect(480, 470, 200, 75));
        btnBack_34->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(uExtHumerusViewPage);
        uExtForearmViewPage = new QWidget();
        uExtForearmViewPage->setObjectName(QString::fromUtf8("uExtForearmViewPage"));
        background_36 = new QLabel(uExtForearmViewPage);
        background_36->setObjectName(QString::fromUtf8("background_36"));
        background_36->setGeometry(QRect(0, 0, 1024, 600));
        background_36->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_20 = new QPushButton(uExtForearmViewPage);
        pushButtonDELETE_20->setObjectName(QString::fromUtf8("pushButtonDELETE_20"));
        pushButtonDELETE_20->setGeometry(QRect(640, 150, 121, 23));
        btnHome_35 = new QPushButton(uExtForearmViewPage);
        btnHome_35->setObjectName(QString::fromUtf8("btnHome_35"));
        btnHome_35->setGeometry(QRect(740, 470, 200, 75));
        btnHome_35->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_35 = new QPushButton(uExtForearmViewPage);
        btnBack_35->setObjectName(QString::fromUtf8("btnBack_35"));
        btnBack_35->setGeometry(QRect(480, 470, 200, 75));
        btnBack_35->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(uExtForearmViewPage);
        uExtFingersViewPage = new QWidget();
        uExtFingersViewPage->setObjectName(QString::fromUtf8("uExtFingersViewPage"));
        background_37 = new QLabel(uExtFingersViewPage);
        background_37->setObjectName(QString::fromUtf8("background_37"));
        background_37->setGeometry(QRect(0, 0, 1024, 600));
        background_37->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_21 = new QPushButton(uExtFingersViewPage);
        pushButtonDELETE_21->setObjectName(QString::fromUtf8("pushButtonDELETE_21"));
        pushButtonDELETE_21->setGeometry(QRect(670, 100, 111, 23));
        btnHome_36 = new QPushButton(uExtFingersViewPage);
        btnHome_36->setObjectName(QString::fromUtf8("btnHome_36"));
        btnHome_36->setGeometry(QRect(740, 470, 200, 75));
        btnHome_36->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_36 = new QPushButton(uExtFingersViewPage);
        btnBack_36->setObjectName(QString::fromUtf8("btnBack_36"));
        btnBack_36->setGeometry(QRect(480, 470, 200, 75));
        btnBack_36->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(uExtFingersViewPage);
        lExtFemurViewPage = new QWidget();
        lExtFemurViewPage->setObjectName(QString::fromUtf8("lExtFemurViewPage"));
        background_38 = new QLabel(lExtFemurViewPage);
        background_38->setObjectName(QString::fromUtf8("background_38"));
        background_38->setGeometry(QRect(0, 0, 1024, 600));
        background_38->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_22 = new QPushButton(lExtFemurViewPage);
        pushButtonDELETE_22->setObjectName(QString::fromUtf8("pushButtonDELETE_22"));
        pushButtonDELETE_22->setGeometry(QRect(660, 140, 80, 23));
        btnHome_37 = new QPushButton(lExtFemurViewPage);
        btnHome_37->setObjectName(QString::fromUtf8("btnHome_37"));
        btnHome_37->setGeometry(QRect(740, 470, 200, 75));
        btnHome_37->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_37 = new QPushButton(lExtFemurViewPage);
        btnBack_37->setObjectName(QString::fromUtf8("btnBack_37"));
        btnBack_37->setGeometry(QRect(480, 470, 200, 75));
        btnBack_37->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(lExtFemurViewPage);
        lExtKneeViewPage = new QWidget();
        lExtKneeViewPage->setObjectName(QString::fromUtf8("lExtKneeViewPage"));
        background_39 = new QLabel(lExtKneeViewPage);
        background_39->setObjectName(QString::fromUtf8("background_39"));
        background_39->setGeometry(QRect(0, 0, 1024, 600));
        background_39->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_23 = new QPushButton(lExtKneeViewPage);
        pushButtonDELETE_23->setObjectName(QString::fromUtf8("pushButtonDELETE_23"));
        pushButtonDELETE_23->setGeometry(QRect(650, 120, 80, 23));
        btnHome_38 = new QPushButton(lExtKneeViewPage);
        btnHome_38->setObjectName(QString::fromUtf8("btnHome_38"));
        btnHome_38->setGeometry(QRect(740, 470, 200, 75));
        btnHome_38->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_38 = new QPushButton(lExtKneeViewPage);
        btnBack_38->setObjectName(QString::fromUtf8("btnBack_38"));
        btnBack_38->setGeometry(QRect(480, 470, 200, 75));
        btnBack_38->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(lExtKneeViewPage);
        lExtAnkleViewPage = new QWidget();
        lExtAnkleViewPage->setObjectName(QString::fromUtf8("lExtAnkleViewPage"));
        background_40 = new QLabel(lExtAnkleViewPage);
        background_40->setObjectName(QString::fromUtf8("background_40"));
        background_40->setGeometry(QRect(0, 0, 1024, 600));
        background_40->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_24 = new QPushButton(lExtAnkleViewPage);
        pushButtonDELETE_24->setObjectName(QString::fromUtf8("pushButtonDELETE_24"));
        pushButtonDELETE_24->setGeometry(QRect(670, 140, 80, 23));
        btnHome_39 = new QPushButton(lExtAnkleViewPage);
        btnHome_39->setObjectName(QString::fromUtf8("btnHome_39"));
        btnHome_39->setGeometry(QRect(740, 470, 200, 75));
        btnHome_39->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_39 = new QPushButton(lExtAnkleViewPage);
        btnBack_39->setObjectName(QString::fromUtf8("btnBack_39"));
        btnBack_39->setGeometry(QRect(480, 470, 200, 75));
        btnBack_39->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(lExtAnkleViewPage);
        lExtToesViewPage = new QWidget();
        lExtToesViewPage->setObjectName(QString::fromUtf8("lExtToesViewPage"));
        background_41 = new QLabel(lExtToesViewPage);
        background_41->setObjectName(QString::fromUtf8("background_41"));
        background_41->setGeometry(QRect(0, 0, 1024, 600));
        background_41->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_25 = new QPushButton(lExtToesViewPage);
        pushButtonDELETE_25->setObjectName(QString::fromUtf8("pushButtonDELETE_25"));
        pushButtonDELETE_25->setGeometry(QRect(650, 140, 80, 23));
        btnHome_40 = new QPushButton(lExtToesViewPage);
        btnHome_40->setObjectName(QString::fromUtf8("btnHome_40"));
        btnHome_40->setGeometry(QRect(740, 470, 200, 75));
        btnHome_40->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_40 = new QPushButton(lExtToesViewPage);
        btnBack_40->setObjectName(QString::fromUtf8("btnBack_40"));
        btnBack_40->setGeometry(QRect(480, 470, 200, 75));
        btnBack_40->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(lExtToesViewPage);
        abdomenProneApViewPage = new QWidget();
        abdomenProneApViewPage->setObjectName(QString::fromUtf8("abdomenProneApViewPage"));
        background_42 = new QLabel(abdomenProneApViewPage);
        background_42->setObjectName(QString::fromUtf8("background_42"));
        background_42->setGeometry(QRect(0, 0, 1024, 600));
        background_42->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_26 = new QPushButton(abdomenProneApViewPage);
        pushButtonDELETE_26->setObjectName(QString::fromUtf8("pushButtonDELETE_26"));
        pushButtonDELETE_26->setGeometry(QRect(660, 130, 80, 23));
        btnHome_41 = new QPushButton(abdomenProneApViewPage);
        btnHome_41->setObjectName(QString::fromUtf8("btnHome_41"));
        btnHome_41->setGeometry(QRect(740, 470, 200, 75));
        btnHome_41->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_41 = new QPushButton(abdomenProneApViewPage);
        btnBack_41->setObjectName(QString::fromUtf8("btnBack_41"));
        btnBack_41->setGeometry(QRect(480, 470, 200, 75));
        btnBack_41->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(abdomenProneApViewPage);
        abdomenProneLatViewPage = new QWidget();
        abdomenProneLatViewPage->setObjectName(QString::fromUtf8("abdomenProneLatViewPage"));
        background_43 = new QLabel(abdomenProneLatViewPage);
        background_43->setObjectName(QString::fromUtf8("background_43"));
        background_43->setGeometry(QRect(0, 0, 1024, 600));
        background_43->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_27 = new QPushButton(abdomenProneLatViewPage);
        pushButtonDELETE_27->setObjectName(QString::fromUtf8("pushButtonDELETE_27"));
        pushButtonDELETE_27->setGeometry(QRect(640, 140, 80, 23));
        btnHome_42 = new QPushButton(abdomenProneLatViewPage);
        btnHome_42->setObjectName(QString::fromUtf8("btnHome_42"));
        btnHome_42->setGeometry(QRect(740, 470, 200, 75));
        btnHome_42->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_42 = new QPushButton(abdomenProneLatViewPage);
        btnBack_42->setObjectName(QString::fromUtf8("btnBack_42"));
        btnBack_42->setGeometry(QRect(480, 470, 200, 75));
        btnBack_42->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(abdomenProneLatViewPage);
        abdomenStandApViewPage = new QWidget();
        abdomenStandApViewPage->setObjectName(QString::fromUtf8("abdomenStandApViewPage"));
        background_44 = new QLabel(abdomenStandApViewPage);
        background_44->setObjectName(QString::fromUtf8("background_44"));
        background_44->setGeometry(QRect(0, 0, 1024, 600));
        background_44->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_28 = new QPushButton(abdomenStandApViewPage);
        pushButtonDELETE_28->setObjectName(QString::fromUtf8("pushButtonDELETE_28"));
        pushButtonDELETE_28->setGeometry(QRect(640, 150, 80, 23));
        btnHome_43 = new QPushButton(abdomenStandApViewPage);
        btnHome_43->setObjectName(QString::fromUtf8("btnHome_43"));
        btnHome_43->setGeometry(QRect(740, 470, 200, 75));
        btnHome_43->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_43 = new QPushButton(abdomenStandApViewPage);
        btnBack_43->setObjectName(QString::fromUtf8("btnBack_43"));
        btnBack_43->setGeometry(QRect(480, 470, 200, 75));
        btnBack_43->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(abdomenStandApViewPage);
        abdomenStandLatViewPage = new QWidget();
        abdomenStandLatViewPage->setObjectName(QString::fromUtf8("abdomenStandLatViewPage"));
        background_45 = new QLabel(abdomenStandLatViewPage);
        background_45->setObjectName(QString::fromUtf8("background_45"));
        background_45->setGeometry(QRect(0, 0, 1024, 600));
        background_45->setPixmap(QPixmap(QString::fromUtf8(":/background/images/background/bgMain.png")));
        pushButtonDELETE_29 = new QPushButton(abdomenStandLatViewPage);
        pushButtonDELETE_29->setObjectName(QString::fromUtf8("pushButtonDELETE_29"));
        pushButtonDELETE_29->setGeometry(QRect(640, 140, 80, 23));
        btnHome_44 = new QPushButton(abdomenStandLatViewPage);
        btnHome_44->setObjectName(QString::fromUtf8("btnHome_44"));
        btnHome_44->setGeometry(QRect(740, 470, 200, 75));
        btnHome_44->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnHome.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnHomeClicked.png);\n"
"}"));
        btnBack_44 = new QPushButton(abdomenStandLatViewPage);
        btnBack_44->setObjectName(QString::fromUtf8("btnBack_44"));
        btnBack_44->setGeometry(QRect(480, 470, 200, 75));
        btnBack_44->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"    border: none;\n"
"    background-color: transparent;\n"
"    background-image: url(:/buttons/images/buttons/btnBack.png);\n"
"    background-repeat: no-repeat;\n"
"    background-position: center;\n"
"}\n"
"QPushButton:pressed {\n"
"    background-image: url(:/buttons/images/buttons/btnBackClicked.png);\n"
"}"));
        stackedWidget->addWidget(abdomenStandLatViewPage);
        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        stackedWidget->setCurrentIndex(0);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        background->setText(QString());
        btnSkull->setText(QString());
        btnSpine->setText(QString());
        btnRibs->setText(QString());
        btnChest->setText(QString());
        btnUExt->setText(QString());
        btnLExt->setText(QString());
        btnAbdomen->setText(QString());
        bodyViewImage->setText(QString());
        background_2->setText(QString());
        btnHome->setText(QString());
        btnBack->setText(QString());
        btnSkullPA->setText(QString());
        btnSkullLAT->setText(QString());
        btnSkullTowne->setText(QString());
        background_3->setText(QString());
        btnHome_2->setText(QString());
        btnBack_2->setText(QString());
        btnSpineCSpine->setText(QCoreApplication::translate("MainWindow", "C Spine", nullptr));
        btnSpineTSpine->setText(QCoreApplication::translate("MainWindow", "T Spine", nullptr));
        btnSpineLSpine->setText(QCoreApplication::translate("MainWindow", "L Spine", nullptr));
        background_4->setText(QString());
        btnHome_3->setText(QString());
        btnBack_3->setText(QString());
        btnRibsThoraxAP->setText(QCoreApplication::translate("MainWindow", "Thorax-AP", nullptr));
        btnRibsThoraxLAT->setText(QCoreApplication::translate("MainWindow", "Thorax-LAT", nullptr));
        btnRibsAbdAP->setText(QCoreApplication::translate("MainWindow", "ABD-AP", nullptr));
        btnRibsAbdLAT->setText(QCoreApplication::translate("MainWindow", "ABD-LAT", nullptr));
        background_5->setText(QString());
        btnHome_4->setText(QString());
        btnBack_4->setText(QString());
        btnChestPA->setText(QCoreApplication::translate("MainWindow", "PA", nullptr));
        btnChestLAT->setText(QCoreApplication::translate("MainWindow", "LAT", nullptr));
        btnChestSupinePA->setText(QCoreApplication::translate("MainWindow", "Supine PA", nullptr));
        btnChestSupineLAT->setText(QCoreApplication::translate("MainWindow", "Supine LAT", nullptr));
        background_6->setText(QString());
        btnHome_5->setText(QString());
        btnBack_5->setText(QString());
        btnUExtShoulder->setText(QCoreApplication::translate("MainWindow", "Shoulder", nullptr));
        btnUExtHumerus->setText(QCoreApplication::translate("MainWindow", "Humerus", nullptr));
        btnUExtForearm->setText(QCoreApplication::translate("MainWindow", "Forearm", nullptr));
        btnUExtFingers->setText(QCoreApplication::translate("MainWindow", "Fingers", nullptr));
        background_7->setText(QString());
        btnHome_6->setText(QString());
        btnBack_6->setText(QString());
        btnLExtFemur->setText(QCoreApplication::translate("MainWindow", "Femur", nullptr));
        btnLExtKnee->setText(QCoreApplication::translate("MainWindow", "Knee", nullptr));
        btnLExtAnkle->setText(QCoreApplication::translate("MainWindow", "Ankle", nullptr));
        btnLExtToes->setText(QCoreApplication::translate("MainWindow", "Toes", nullptr));
        background_8->setText(QString());
        btnHome_7->setText(QString());
        btnBack_7->setText(QString());
        btnAbdomenProneAP->setText(QCoreApplication::translate("MainWindow", "Prone-AP", nullptr));
        btnAbdomenProneLAT->setText(QCoreApplication::translate("MainWindow", "Prone-LAT", nullptr));
        btnAbdomenStandAP->setText(QCoreApplication::translate("MainWindow", "Stand-AP", nullptr));
        btnAbdomenStandLAT->setText(QCoreApplication::translate("MainWindow", "Stand-LAT", nullptr));
        background_9->setText(QString());
        btnHome_9->setText(QString());
        btnBack_8->setText(QString());
        background_10->setText(QString());
        btnHome_8->setText(QString());
        btnBack_9->setText(QString());
        background_11->setText(QString());
        btnHome_10->setText(QString());
        btnBack_10->setText(QString());
        background_12->setText(QString());
        btnHome_11->setText(QString());
        btnBack_11->setText(QString());
        btnSpineCSpineAP->setText(QCoreApplication::translate("MainWindow", "AP", nullptr));
        btnSpineCSpineLAT->setText(QCoreApplication::translate("MainWindow", "LAT", nullptr));
        btnSpineCSpineOblique->setText(QCoreApplication::translate("MainWindow", "Oblique", nullptr));
        background_13->setText(QString());
        btnHome_12->setText(QString());
        btnBack_12->setText(QString());
        btnSpineTSpineAP->setText(QCoreApplication::translate("MainWindow", "AP", nullptr));
        btnSpineTSpineLAT->setText(QCoreApplication::translate("MainWindow", "LAT", nullptr));
        btnSpineTSpineSternAP->setText(QCoreApplication::translate("MainWindow", "SternAP", nullptr));
        btnSpineTSpineSternLAT->setText(QCoreApplication::translate("MainWindow", "SternLAT", nullptr));
        background_14->setText(QString());
        btnHome_13->setText(QString());
        btnBack_13->setText(QString());
        btnSpineLSpineAP->setText(QCoreApplication::translate("MainWindow", "AP", nullptr));
        btnSpineLSpineLAT->setText(QCoreApplication::translate("MainWindow", "LAT", nullptr));
        btnSpineLSpineOblique->setText(QCoreApplication::translate("MainWindow", "Oblique", nullptr));
        btnSpineLSpinePelvis->setText(QCoreApplication::translate("MainWindow", "Pelvis", nullptr));
        background_15->setText(QString());
        btnHome_14->setText(QString());
        btnBack_14->setText(QString());
        pushButtonDELETE->setText(QCoreApplication::translate("MainWindow", "CSpine AP", nullptr));
        background_16->setText(QString());
        btnHome_15->setText(QString());
        btnBack_15->setText(QString());
        pushButton_2DELETE->setText(QCoreApplication::translate("MainWindow", "CSpine LAT", nullptr));
        background_17->setText(QString());
        btnHome_16->setText(QString());
        btnBack_16->setText(QString());
        pushButton_3DELETE->setText(QCoreApplication::translate("MainWindow", "CSpine Obliuqe", nullptr));
        background_18->setText(QString());
        btnHome_17->setText(QString());
        btnBack_17->setText(QString());
        pushButtonDELETE_2->setText(QCoreApplication::translate("MainWindow", "TSpine AP", nullptr));
        background_19->setText(QString());
        btnHome_18->setText(QString());
        btnBack_18->setText(QString());
        pushButtonDELETE_3->setText(QCoreApplication::translate("MainWindow", "TSpine LAT", nullptr));
        background_20->setText(QString());
        btnHome_19->setText(QString());
        btnBack_19->setText(QString());
        pushButtonDELETE_4->setText(QCoreApplication::translate("MainWindow", "TSpine SternAP", nullptr));
        background_21->setText(QString());
        btnHome_20->setText(QString());
        btnBack_20->setText(QString());
        pushButtonDELETE_5->setText(QCoreApplication::translate("MainWindow", "TSpine SternLAT", nullptr));
        background_22->setText(QString());
        pushButtonDELETE_6->setText(QCoreApplication::translate("MainWindow", "LSpine AP", nullptr));
        btnHome_21->setText(QString());
        btnBack_21->setText(QString());
        background_23->setText(QString());
        pushButtonDELETE_7->setText(QCoreApplication::translate("MainWindow", "LSpine LAT", nullptr));
        btnHome_22->setText(QString());
        btnBack_22->setText(QString());
        background_24->setText(QString());
        pushButtonDELETE_8->setText(QCoreApplication::translate("MainWindow", "LSpine Oblique", nullptr));
        btnHome_23->setText(QString());
        btnBack_23->setText(QString());
        background_25->setText(QString());
        pushButtonDELETE_9->setText(QCoreApplication::translate("MainWindow", "LSpine Pelvis", nullptr));
        btnHome_24->setText(QString());
        btnBack_24->setText(QString());
        background_26->setText(QString());
        btnHome_25->setText(QString());
        btnBack_25->setText(QString());
        pushButtonDELETE_10->setText(QCoreApplication::translate("MainWindow", "Ribs Thorax AP", nullptr));
        background_27->setText(QString());
        btnHome_26->setText(QString());
        btnBack_26->setText(QString());
        pushButtonDELETE_11->setText(QCoreApplication::translate("MainWindow", "Ribs Thorax LAT", nullptr));
        background_28->setText(QString());
        btnHome_27->setText(QString());
        btnBack_27->setText(QString());
        pushButtonDELETE_12->setText(QCoreApplication::translate("MainWindow", "Ribs ABD AP", nullptr));
        background_29->setText(QString());
        btnHome_28->setText(QString());
        btnBack_28->setText(QString());
        pushButtonDELETE_13->setText(QCoreApplication::translate("MainWindow", "Ribs ABD LAT", nullptr));
        background_30->setText(QString());
        pushButtonDELETE_14->setText(QCoreApplication::translate("MainWindow", "Chest PA", nullptr));
        btnHome_29->setText(QString());
        btnBack_29->setText(QString());
        background_31->setText(QString());
        pushButtonDELETE_15->setText(QCoreApplication::translate("MainWindow", "Chest LAT", nullptr));
        btnHome_30->setText(QString());
        btnBack_30->setText(QString());
        background_32->setText(QString());
        pushButtonDELETE_16->setText(QCoreApplication::translate("MainWindow", "Chest Supine PA", nullptr));
        btnHome_31->setText(QString());
        btnBack_31->setText(QString());
        background_33->setText(QString());
        pushButtonDELETE_17->setText(QCoreApplication::translate("MainWindow", "Chest Supine LAT", nullptr));
        btnHome_32->setText(QString());
        btnBack_32->setText(QString());
        background_34->setText(QString());
        pushButtonDELETE_18->setText(QCoreApplication::translate("MainWindow", "UExt Shoulder", nullptr));
        btnHome_33->setText(QString());
        btnBack_33->setText(QString());
        background_35->setText(QString());
        pushButtonDELETE_19->setText(QCoreApplication::translate("MainWindow", "UExt Humerus", nullptr));
        btnHome_34->setText(QString());
        btnBack_34->setText(QString());
        background_36->setText(QString());
        pushButtonDELETE_20->setText(QCoreApplication::translate("MainWindow", "UExt Forearm", nullptr));
        btnHome_35->setText(QString());
        btnBack_35->setText(QString());
        background_37->setText(QString());
        pushButtonDELETE_21->setText(QCoreApplication::translate("MainWindow", "UExt Fingers", nullptr));
        btnHome_36->setText(QString());
        btnBack_36->setText(QString());
        background_38->setText(QString());
        pushButtonDELETE_22->setText(QCoreApplication::translate("MainWindow", "Femur", nullptr));
        btnHome_37->setText(QString());
        btnBack_37->setText(QString());
        background_39->setText(QString());
        pushButtonDELETE_23->setText(QCoreApplication::translate("MainWindow", "Knee", nullptr));
        btnHome_38->setText(QString());
        btnBack_38->setText(QString());
        background_40->setText(QString());
        pushButtonDELETE_24->setText(QCoreApplication::translate("MainWindow", "Ankle", nullptr));
        btnHome_39->setText(QString());
        btnBack_39->setText(QString());
        background_41->setText(QString());
        pushButtonDELETE_25->setText(QCoreApplication::translate("MainWindow", "Toes", nullptr));
        btnHome_40->setText(QString());
        btnBack_40->setText(QString());
        background_42->setText(QString());
        pushButtonDELETE_26->setText(QCoreApplication::translate("MainWindow", "ProneAP", nullptr));
        btnHome_41->setText(QString());
        btnBack_41->setText(QString());
        background_43->setText(QString());
        pushButtonDELETE_27->setText(QCoreApplication::translate("MainWindow", "ProneLAT", nullptr));
        btnHome_42->setText(QString());
        btnBack_42->setText(QString());
        background_44->setText(QString());
        pushButtonDELETE_28->setText(QCoreApplication::translate("MainWindow", "StandAP", nullptr));
        btnHome_43->setText(QString());
        btnBack_43->setText(QString());
        background_45->setText(QString());
        pushButtonDELETE_29->setText(QCoreApplication::translate("MainWindow", "StandLAT", nullptr));
        btnHome_44->setText(QString());
        btnBack_44->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
