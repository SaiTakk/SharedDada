/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.3)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.3. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[48];
    char stringdata0[1196];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 19), // "on_btnSkull_clicked"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 19), // "on_btnSpine_clicked"
QT_MOC_LITERAL(4, 52, 18), // "on_btnRibs_clicked"
QT_MOC_LITERAL(5, 71, 19), // "on_btnChest_clicked"
QT_MOC_LITERAL(6, 91, 18), // "on_btnUExt_clicked"
QT_MOC_LITERAL(7, 110, 18), // "on_btnLExt_clicked"
QT_MOC_LITERAL(8, 129, 21), // "on_btnAbdomen_clicked"
QT_MOC_LITERAL(9, 151, 18), // "on_btnHome_clicked"
QT_MOC_LITERAL(10, 170, 18), // "on_btnBack_clicked"
QT_MOC_LITERAL(11, 189, 21), // "on_btnSkullPA_clicked"
QT_MOC_LITERAL(12, 211, 22), // "on_btnSkullLAT_clicked"
QT_MOC_LITERAL(13, 234, 24), // "on_btnSkullTowne_clicked"
QT_MOC_LITERAL(14, 259, 25), // "on_btnSpineCSpine_clicked"
QT_MOC_LITERAL(15, 285, 25), // "on_btnSpineTSpine_clicked"
QT_MOC_LITERAL(16, 311, 25), // "on_btnSpineLSpine_clicked"
QT_MOC_LITERAL(17, 337, 27), // "on_btnSpineCSpineAP_clicked"
QT_MOC_LITERAL(18, 365, 28), // "on_btnSpineCSpineLAT_clicked"
QT_MOC_LITERAL(19, 394, 32), // "on_btnSpineCSpineOblique_clicked"
QT_MOC_LITERAL(20, 427, 27), // "on_btnSpineTSpineAP_clicked"
QT_MOC_LITERAL(21, 455, 28), // "on_btnSpineTSpineLAT_clicked"
QT_MOC_LITERAL(22, 484, 32), // "on_btnSpineTSpineSternAP_clicked"
QT_MOC_LITERAL(23, 517, 33), // "on_btnSpineTSpineSternLAT_cli..."
QT_MOC_LITERAL(24, 551, 27), // "on_btnSpineLSpineAP_clicked"
QT_MOC_LITERAL(25, 579, 28), // "on_btnSpineLSpineLAT_clicked"
QT_MOC_LITERAL(26, 608, 32), // "on_btnSpineLSpineOblique_clicked"
QT_MOC_LITERAL(27, 641, 31), // "on_btnSpineLSpinePelvis_clicked"
QT_MOC_LITERAL(28, 673, 26), // "on_btnRibsThoraxAP_clicked"
QT_MOC_LITERAL(29, 700, 27), // "on_btnRibsThoraxLAT_clicked"
QT_MOC_LITERAL(30, 728, 23), // "on_btnRibsAbdAP_clicked"
QT_MOC_LITERAL(31, 752, 24), // "on_btnRibsAbdLAT_clicked"
QT_MOC_LITERAL(32, 777, 21), // "on_btnChestPA_clicked"
QT_MOC_LITERAL(33, 799, 22), // "on_btnChestLAT_clicked"
QT_MOC_LITERAL(34, 822, 27), // "on_btnChestSupinePA_clicked"
QT_MOC_LITERAL(35, 850, 28), // "on_btnChestSupineLAT_clicked"
QT_MOC_LITERAL(36, 879, 26), // "on_btnUExtShoulder_clicked"
QT_MOC_LITERAL(37, 906, 25), // "on_btnUExtHumerus_clicked"
QT_MOC_LITERAL(38, 932, 25), // "on_btnUExtForearm_clicked"
QT_MOC_LITERAL(39, 958, 25), // "on_btnUExtFingers_clicked"
QT_MOC_LITERAL(40, 984, 23), // "on_btnLExtFemur_clicked"
QT_MOC_LITERAL(41, 1008, 22), // "on_btnLExtKnee_clicked"
QT_MOC_LITERAL(42, 1031, 23), // "on_btnLExtAnkle_clicked"
QT_MOC_LITERAL(43, 1055, 22), // "on_btnLExtToes_clicked"
QT_MOC_LITERAL(44, 1078, 28), // "on_btnAbdomenProneAP_clicked"
QT_MOC_LITERAL(45, 1107, 29), // "on_btnAbdomenProneLAT_clicked"
QT_MOC_LITERAL(46, 1137, 28), // "on_btnAbdomenStandAP_clicked"
QT_MOC_LITERAL(47, 1166, 29) // "on_btnAbdomenStandLAT_clicked"

    },
    "MainWindow\0on_btnSkull_clicked\0\0"
    "on_btnSpine_clicked\0on_btnRibs_clicked\0"
    "on_btnChest_clicked\0on_btnUExt_clicked\0"
    "on_btnLExt_clicked\0on_btnAbdomen_clicked\0"
    "on_btnHome_clicked\0on_btnBack_clicked\0"
    "on_btnSkullPA_clicked\0on_btnSkullLAT_clicked\0"
    "on_btnSkullTowne_clicked\0"
    "on_btnSpineCSpine_clicked\0"
    "on_btnSpineTSpine_clicked\0"
    "on_btnSpineLSpine_clicked\0"
    "on_btnSpineCSpineAP_clicked\0"
    "on_btnSpineCSpineLAT_clicked\0"
    "on_btnSpineCSpineOblique_clicked\0"
    "on_btnSpineTSpineAP_clicked\0"
    "on_btnSpineTSpineLAT_clicked\0"
    "on_btnSpineTSpineSternAP_clicked\0"
    "on_btnSpineTSpineSternLAT_clicked\0"
    "on_btnSpineLSpineAP_clicked\0"
    "on_btnSpineLSpineLAT_clicked\0"
    "on_btnSpineLSpineOblique_clicked\0"
    "on_btnSpineLSpinePelvis_clicked\0"
    "on_btnRibsThoraxAP_clicked\0"
    "on_btnRibsThoraxLAT_clicked\0"
    "on_btnRibsAbdAP_clicked\0"
    "on_btnRibsAbdLAT_clicked\0on_btnChestPA_clicked\0"
    "on_btnChestLAT_clicked\0"
    "on_btnChestSupinePA_clicked\0"
    "on_btnChestSupineLAT_clicked\0"
    "on_btnUExtShoulder_clicked\0"
    "on_btnUExtHumerus_clicked\0"
    "on_btnUExtForearm_clicked\0"
    "on_btnUExtFingers_clicked\0"
    "on_btnLExtFemur_clicked\0on_btnLExtKnee_clicked\0"
    "on_btnLExtAnkle_clicked\0on_btnLExtToes_clicked\0"
    "on_btnAbdomenProneAP_clicked\0"
    "on_btnAbdomenProneLAT_clicked\0"
    "on_btnAbdomenStandAP_clicked\0"
    "on_btnAbdomenStandLAT_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      46,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  244,    2, 0x08 /* Private */,
       3,    0,  245,    2, 0x08 /* Private */,
       4,    0,  246,    2, 0x08 /* Private */,
       5,    0,  247,    2, 0x08 /* Private */,
       6,    0,  248,    2, 0x08 /* Private */,
       7,    0,  249,    2, 0x08 /* Private */,
       8,    0,  250,    2, 0x08 /* Private */,
       9,    0,  251,    2, 0x08 /* Private */,
      10,    0,  252,    2, 0x08 /* Private */,
      11,    0,  253,    2, 0x08 /* Private */,
      12,    0,  254,    2, 0x08 /* Private */,
      13,    0,  255,    2, 0x08 /* Private */,
      14,    0,  256,    2, 0x08 /* Private */,
      15,    0,  257,    2, 0x08 /* Private */,
      16,    0,  258,    2, 0x08 /* Private */,
      17,    0,  259,    2, 0x08 /* Private */,
      18,    0,  260,    2, 0x08 /* Private */,
      19,    0,  261,    2, 0x08 /* Private */,
      20,    0,  262,    2, 0x08 /* Private */,
      21,    0,  263,    2, 0x08 /* Private */,
      22,    0,  264,    2, 0x08 /* Private */,
      23,    0,  265,    2, 0x08 /* Private */,
      24,    0,  266,    2, 0x08 /* Private */,
      25,    0,  267,    2, 0x08 /* Private */,
      26,    0,  268,    2, 0x08 /* Private */,
      27,    0,  269,    2, 0x08 /* Private */,
      28,    0,  270,    2, 0x08 /* Private */,
      29,    0,  271,    2, 0x08 /* Private */,
      30,    0,  272,    2, 0x08 /* Private */,
      31,    0,  273,    2, 0x08 /* Private */,
      32,    0,  274,    2, 0x08 /* Private */,
      33,    0,  275,    2, 0x08 /* Private */,
      34,    0,  276,    2, 0x08 /* Private */,
      35,    0,  277,    2, 0x08 /* Private */,
      36,    0,  278,    2, 0x08 /* Private */,
      37,    0,  279,    2, 0x08 /* Private */,
      38,    0,  280,    2, 0x08 /* Private */,
      39,    0,  281,    2, 0x08 /* Private */,
      40,    0,  282,    2, 0x08 /* Private */,
      41,    0,  283,    2, 0x08 /* Private */,
      42,    0,  284,    2, 0x08 /* Private */,
      43,    0,  285,    2, 0x08 /* Private */,
      44,    0,  286,    2, 0x08 /* Private */,
      45,    0,  287,    2, 0x08 /* Private */,
      46,    0,  288,    2, 0x08 /* Private */,
      47,    0,  289,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->on_btnSkull_clicked(); break;
        case 1: _t->on_btnSpine_clicked(); break;
        case 2: _t->on_btnRibs_clicked(); break;
        case 3: _t->on_btnChest_clicked(); break;
        case 4: _t->on_btnUExt_clicked(); break;
        case 5: _t->on_btnLExt_clicked(); break;
        case 6: _t->on_btnAbdomen_clicked(); break;
        case 7: _t->on_btnHome_clicked(); break;
        case 8: _t->on_btnBack_clicked(); break;
        case 9: _t->on_btnSkullPA_clicked(); break;
        case 10: _t->on_btnSkullLAT_clicked(); break;
        case 11: _t->on_btnSkullTowne_clicked(); break;
        case 12: _t->on_btnSpineCSpine_clicked(); break;
        case 13: _t->on_btnSpineTSpine_clicked(); break;
        case 14: _t->on_btnSpineLSpine_clicked(); break;
        case 15: _t->on_btnSpineCSpineAP_clicked(); break;
        case 16: _t->on_btnSpineCSpineLAT_clicked(); break;
        case 17: _t->on_btnSpineCSpineOblique_clicked(); break;
        case 18: _t->on_btnSpineTSpineAP_clicked(); break;
        case 19: _t->on_btnSpineTSpineLAT_clicked(); break;
        case 20: _t->on_btnSpineTSpineSternAP_clicked(); break;
        case 21: _t->on_btnSpineTSpineSternLAT_clicked(); break;
        case 22: _t->on_btnSpineLSpineAP_clicked(); break;
        case 23: _t->on_btnSpineLSpineLAT_clicked(); break;
        case 24: _t->on_btnSpineLSpineOblique_clicked(); break;
        case 25: _t->on_btnSpineLSpinePelvis_clicked(); break;
        case 26: _t->on_btnRibsThoraxAP_clicked(); break;
        case 27: _t->on_btnRibsThoraxLAT_clicked(); break;
        case 28: _t->on_btnRibsAbdAP_clicked(); break;
        case 29: _t->on_btnRibsAbdLAT_clicked(); break;
        case 30: _t->on_btnChestPA_clicked(); break;
        case 31: _t->on_btnChestLAT_clicked(); break;
        case 32: _t->on_btnChestSupinePA_clicked(); break;
        case 33: _t->on_btnChestSupineLAT_clicked(); break;
        case 34: _t->on_btnUExtShoulder_clicked(); break;
        case 35: _t->on_btnUExtHumerus_clicked(); break;
        case 36: _t->on_btnUExtForearm_clicked(); break;
        case 37: _t->on_btnUExtFingers_clicked(); break;
        case 38: _t->on_btnLExtFemur_clicked(); break;
        case 39: _t->on_btnLExtKnee_clicked(); break;
        case 40: _t->on_btnLExtAnkle_clicked(); break;
        case 41: _t->on_btnLExtToes_clicked(); break;
        case 42: _t->on_btnAbdomenProneAP_clicked(); break;
        case 43: _t->on_btnAbdomenProneLAT_clicked(); break;
        case 44: _t->on_btnAbdomenStandAP_clicked(); break;
        case 45: _t->on_btnAbdomenStandLAT_clicked(); break;
        default: ;
        }
    }
    (void)_a;
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 46)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 46;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 46)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 46;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
